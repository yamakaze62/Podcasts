<?php
#on s'aide de la librairie getID3

require_once('./getID3-master/demos/demo.audioinfo.class.php');

    /* avec la classe fournie on
    peut récupérer toutes les infos sur notre Objet (notre podcast) */


   $au = new AudioInfo(); 

   /*
   dans le fichier de getID3 on récupère beaucoup d'informations
   par rapport au fichier passé
   en paramètre. On a décidé de se limiter seulement
   à quelques infos intéressantes pour nous. 

   */
   print_r($au->Info('IA_antibiotiques.mp3'));
   


?>
